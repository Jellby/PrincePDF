load_translations()

help_txt = _('''
<h3 style="text-align:center">The Prince PDF Plugin</h3>
<p style="text-align:center"><i>Created by Jellby</i></p>

<hr/>

<p style="margin:0">This plugin will convert a book to PDF using Prince.</p>
<p style="margin:0">Prince is an external program, you can download it from <a href="http://www.princexml.com/">www.princexml.com</a>.<br/></p>

<p style="margin:0">Only a few formats can be converted with this plugin, mainly EPUB, AZW3 and HTMLZ. If you want to convert a book in another format, convert it first to one of these formats.<br/></p>

<p style="margin:0">Before the actual conversion, you will be able to choose whether or not to add the resulting PDF to the book record. If the PDF is not added, it will be saved in disk, using the save-to-disk template.<br/></p>

<p style="margin:0">The conversion will not use any of the other calibre settings, but instead it will use a custom CSS file, where Prince-specific properties can be used. This file can be modified in the plugin configuration. In addition, the plugin will recognize and use any extra CSS file specified in the book itself, as a <code>&lt;meta&gt;</code> tag with <code>name="prince-style"</code> and <code>content="<i>idref</i>"</code>, where <code><i>idref</i></code> is the <code>id</code> of the CSS file in the manifest.</p>
''')
